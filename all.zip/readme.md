cfido bbs 的nodelist

list.html是按照nodelist的日期进行排序
